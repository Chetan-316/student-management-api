from ninja import Schema

class StudentSchema(Schema):
    name: str
    age: int
    email: str
    class_name: str  # Added field for student class

class StudentResponseSchema(StudentSchema):
    id: int

