from ninja import NinjaAPI
from django.shortcuts import get_object_or_404
from .models import Student

api = NinjaAPI()

# CRUD Endpoints for Student Management
@api.get("/students")
def list_students(request):
    return list(Student.objects.values())

@api.post("/students")
def create_student(request, name: str, age: int, student_class: str, email: str):
    student = Student.objects.create(name=name, age=age, student_class=student_class, email=email)
    return {"id": student.id, "message": "Student created successfully"}

@api.get("/students/{student_id}")
def get_student(request, student_id: int):
    student = get_object_or_404(Student, id=student_id)
    return {"id": student.id, "name": student.name, "age": student.age, "class": student.student_class, "email": student.email}

@api.put("/students/{student_id}")
def update_student(request, student_id: int, name: str = None, age: int = None, student_class: str = None, email: str = None):
    student = get_object_or_404(Student, id=student_id)
    if name:
        student.name = name
    if age:
        student.age = age
    if student_class:
        student.student_class = student_class
    if email:
        student.email = email
    student.save()
    return {"message": "Student updated successfully"}

@api.delete("/students/{student_id}")
def delete_student(request, student_id: int):
    student = get_object_or_404(Student, id=student_id)
    student.delete()
    return {"message": "Student deleted successfully"}